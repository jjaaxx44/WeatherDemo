"""Configuration for LLMG scanners."""
from __future__ import annotations

from typing import Any


class ScannerConfig:
    """Configuration for scanner behavior."""
    
    # Default thresholds
    DEFAULT_THRESHOLD = 0.5
    STRICT_THRESHOLD = 0.3
    LENIENT_THRESHOLD = 0.7
    
    # Logging
    LOG_LEVEL = "INFO"
    
    # Token limits
    DEFAULT_MAX_TOKENS = 4096
    
    @classmethod
    def get_default_input_config(cls) -> dict[str, Any]:
        """Get default configuration for input scanners."""
        return {
            "prompt_injection": {"threshold": cls.DEFAULT_THRESHOLD},
            "secrets": {"threshold": cls.DEFAULT_THRESHOLD, "redact": True},
            "toxicity": {"threshold": cls.DEFAULT_THRESHOLD},
            "ban_substrings": {"threshold": cls.DEFAULT_THRESHOLD, "redact": False},
            "ban_topics": {"threshold": cls.DEFAULT_THRESHOLD},
            "code_scanner": {"threshold": cls.DEFAULT_THRESHOLD, "allow": True},
            "gibberish": {"threshold": cls.LENIENT_THRESHOLD},
            "invisible_text": {"threshold": cls.DEFAULT_THRESHOLD, "remove": True},
            "token_limit": {
                "max_tokens": cls.DEFAULT_MAX_TOKENS,
                "threshold": 0.8,
                "truncate": False,
            },
        }
    
    @classmethod
    def get_default_output_config(cls) -> dict[str, Any]:
        """Get default configuration for output scanners."""
        return {
            "toxicity": {"threshold": cls.DEFAULT_THRESHOLD},
            "bias": {"threshold": 0.6},
            "no_refusal": {"threshold": cls.DEFAULT_THRESHOLD},
            "relevance": {"threshold": 0.3},
            "sensitive": {"threshold": cls.DEFAULT_THRESHOLD, "redact": True},
            "ban_substrings": {"threshold": cls.DEFAULT_THRESHOLD, "redact": False},
            "ban_topics": {"threshold": cls.DEFAULT_THRESHOLD},
            "code_scanner": {"threshold": cls.DEFAULT_THRESHOLD, "allow": True},
        }
    
    @classmethod
    def get_strict_config(cls) -> dict[str, Any]:
        """Get strict configuration (lower thresholds)."""
        config = cls.get_default_input_config()
        for scanner_config in config.values():
            if "threshold" in scanner_config:
                scanner_config["threshold"] = cls.STRICT_THRESHOLD
        return config
    
    @classmethod
    def get_lenient_config(cls) -> dict[str, Any]:
        """Get lenient configuration (higher thresholds)."""
        config = cls.get_default_input_config()
        for scanner_config in config.values():
            if "threshold" in scanner_config:
                scanner_config["threshold"] = cls.LENIENT_THRESHOLD
        return config
