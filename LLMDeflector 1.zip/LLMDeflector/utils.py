"""
Utility functions for LLMG.
"""
from __future__ import annotations

import logging
import re
from typing import Any

# Configure basic logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)


def get_logger(name: str | None = None) -> logging.Logger:
    """Get a logger instance."""
    if name is None:
        name = "llmg"
    return logging.getLogger(name)


def calculate_risk_score(score: float, threshold: float) -> float:
    """
    Calculate normalized risk score based on threshold.
    Returns value between -1 (well below threshold) and 1 (well above threshold).
    
    Args:
        score: The raw score value
        threshold: The threshold value
        
    Returns:
        Risk score between -1 and 1
    """
    if score > threshold:
        risk_score = round((score - threshold) / (1 - threshold), 2)
    else:
        risk_score = round((score - threshold) / threshold, 2)
    
    return min(max(risk_score, -1), 1)


def extract_urls(text: str) -> list[str]:
    """Extract URLs from text."""
    url_pattern = re.compile(
        r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
    )
    return url_pattern.findall(text)


def extract_emails(text: str) -> list[str]:
    """Extract email addresses from text."""
    email_pattern = re.compile(
        r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    )
    return email_pattern.findall(text)


def extract_phone_numbers(text: str) -> list[str]:
    """Extract phone numbers from text (various formats)."""
    phone_patterns = [
        r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b',  # 123-456-7890 or 1234567890
        r'\b\(\d{3}\)\s*\d{3}[-.]?\d{4}\b',  # (123) 456-7890
        r'\b\d{3}\s\d{3}\s\d{4}\b',  # 123 456 7890
    ]
    
    phone_numbers = []
    for pattern in phone_patterns:
        phone_numbers.extend(re.findall(pattern, text))
    
    return phone_numbers


def extract_credit_cards(text: str) -> list[str]:
    """Extract potential credit card numbers from text."""
    # Match common credit card patterns (with or without separators)
    cc_pattern = re.compile(
        r'\b(?:\d{4}[-\s]?){3}\d{4}\b'
    )
    return cc_pattern.findall(text)


def extract_ip_addresses(text: str) -> list[str]:
    """Extract IP addresses from text."""
    ip_pattern = re.compile(
        r'\b(?:\d{1,3}\.){3}\d{1,3}\b'
    )
    return ip_pattern.findall(text)


def extract_ssn(text: str) -> list[str]:
    """Extract potential SSN patterns from text."""
    ssn_pattern = re.compile(
        r'\b\d{3}[-]?\d{2}[-]?\d{4}\b'
    )
    return ssn_pattern.findall(text)


def contains_code(text: str) -> bool:
    """
    Detect if text contains code snippets.
    Looks for common code patterns.
    """
    code_indicators = [
        r'```',  # Markdown code blocks
        r'def\s+\w+\s*\(',  # Python function
        r'function\s+\w+\s*\(',  # JavaScript function
        r'class\s+\w+\s*[:{]',  # Class definition
        r'import\s+[\w.]+',  # Import statements
        r'from\s+[\w.]+\s+import',  # Python imports
        r'SELECT\s+.*\s+FROM',  # SQL
        r'<\?php',  # PHP
        r'public\s+class\s+\w+',  # Java class
    ]
    
    for pattern in code_indicators:
        if re.search(pattern, text, re.IGNORECASE):
            return True
    
    return False


def split_sentences(text: str) -> list[str]:
    """
    Simple sentence splitter.
    Splits on common sentence boundaries.
    """
    # Split on period, exclamation, question mark followed by space or end
    sentences = re.split(r'[.!?]+\s+|\n+', text)
    return [s.strip() for s in sentences if s.strip()]


def normalize_text(text: str) -> str:
    """Normalize text by lowercasing and removing extra whitespace."""
    text = text.lower()
    text = re.sub(r'\s+', ' ', text)
    return text.strip()


def count_words(text: str) -> int:
    """Count words in text."""
    return len(text.split())


def contains_invisible_chars(text: str) -> bool:
    """Check if text contains invisible Unicode characters."""
    invisible_chars = [
        '\u200b',  # Zero width space
        '\u200c',  # Zero width non-joiner
        '\u200d',  # Zero width joiner
        '\ufeff',  # Zero width no-break space
        '\u2060',  # Word joiner
        '\u180e',  # Mongolian vowel separator
    ]
    
    for char in invisible_chars:
        if char in text:
            return True
    
    return False
