"""LLMDeflector - Rule-Based LLM Security Scanner
A lightweight, rule-based security scanning system for LLM inputs and outputs.

Inspired by Star Trek's deflector shields that protect starships from threats.
"""

from .evaluate import scan_input, scan_output

__version__ = "0.1.0"
__all__ = ["scan_input", "scan_output"]
