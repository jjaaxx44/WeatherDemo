"""Code detection scanner for outputs."""
from __future__ import annotations

from ..utils import calculate_risk_score, contains_code, get_logger
from .base import OutputScanner

LOGGER = get_logger(__name__)


class CodeScanner(OutputScanner):
    """
    Detects code in LLM outputs.
    """

    def __init__(self, threshold: float = 0.5, allow: bool = True):
        """
        Initialize the code scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
            allow: If True, code is allowed. If False, code is flagged.
        """
        self.threshold = threshold
        self.allow = allow

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for code."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        has_code = contains_code(output)
        
        if not has_code:
            return output, True, 0.0
        
        if self.allow:
            LOGGER.debug("Code detected in output but allowed")
            return output, True, 0.0
        else:
            raw_score = 0.8
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(f"Code detected in output. Risk score: {risk_score:.2f}")
            return output, is_valid, risk_score
