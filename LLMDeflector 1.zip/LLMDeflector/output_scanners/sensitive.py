"""Sensitive data detection scanner."""
from __future__ import annotations

from ..utils import (
    calculate_risk_score,
    extract_credit_cards,
    extract_emails,
    extract_ip_addresses,
    extract_phone_numbers,
    extract_ssn,
    get_logger,
)
from .base import OutputScanner

LOGGER = get_logger(__name__)


class SensitiveData(OutputScanner):
    """
    Detects sensitive data in LLM outputs.
    
    Prevents the model from leaking PII or sensitive information.
    """

    def __init__(self, threshold: float = 0.5, redact: bool = True):
        """
        Initialize the sensitive data scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
            redact: Whether to redact found sensitive data.
        """
        self.threshold = threshold
        self.redact = redact

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for sensitive data."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        sanitized_output = output
        sensitive_found = []
        
        # Check for PII
        credit_cards = extract_credit_cards(output)
        if credit_cards:
            sensitive_found.extend([("CREDIT_CARD", cc) for cc in credit_cards])
        
        ssns = extract_ssn(output)
        if ssns:
            sensitive_found.extend([("SSN", ssn) for ssn in ssns])
        
        phone_numbers = extract_phone_numbers(output)
        if phone_numbers:
            sensitive_found.extend([("PHONE", phone) for phone in phone_numbers])
        
        emails = extract_emails(output)
        if emails:
            sensitive_found.extend([("EMAIL", email) for email in emails])
        
        ip_addresses = extract_ip_addresses(output)
        if ip_addresses:
            sensitive_found.extend([("IP_ADDRESS", ip) for ip in ip_addresses])
        
        # Calculate risk score
        if len(sensitive_found) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            raw_score = min(len(sensitive_found) * 0.3, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(
                f"Sensitive data in output: {len(sensitive_found)} item(s) found. "
                f"Types: {set([s[0] for s in sensitive_found])}"
            )
            
            # Redact if enabled
            if self.redact:
                for data_type, data_value in sensitive_found:
                    sanitized_output = sanitized_output.replace(
                        data_value, f"[REDACTED_{data_type}]"
                    )
        
        return sanitized_output, is_valid, risk_score
