"""No refusal detection scanner."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import OutputScanner

LOGGER = get_logger(__name__)


class NoRefusal(OutputScanner):
    """
    Detects if the LLM refused to answer.
    
    Useful for identifying when the model declines to provide information.
    """

    def __init__(self, threshold: float = 0.5):
        """
        Initialize the no refusal scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
        """
        self.threshold = threshold
        
        # Refusal patterns
        self.refusal_patterns = [
            r'\bi\s+(cannot|can\'t|won\'t|will not)\s+(help|assist|provide|answer)',
            r'\bi\'m\s+(not\s+able|unable)\s+to\s+(help|assist|provide|answer)',
            r'\bi\s+don\'t\s+have\s+(access|information|the ability)',
            r'\bi\s+(apologize|sorry),?\s+but\s+i\s+(cannot|can\'t)',
            r'\bthat\'s\s+not\s+something\s+i\s+can\b',
            r'\bi\'m\s+not\s+(allowed|permitted|authorized)\s+to\b',
            r'\bas\s+an\s+ai\s+(language\s+)?model,?\s+i\s+(cannot|can\'t)',
            r'\bi\s+must\s+(decline|refuse)\b',
        ]
        
        self.compiled_patterns = [re.compile(p, re.IGNORECASE) for p in self.refusal_patterns]

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for refusal."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        normalized = normalize_text(output)
        
        # Check for refusal patterns
        refusal_matches = 0
        for pattern in self.compiled_patterns:
            if pattern.search(normalized):
                refusal_matches += 1
        
        if refusal_matches == 0:
            return output, True, 0.0
        
        # Calculate risk score
        # Even one refusal is significant
        raw_score = min(0.7 + (refusal_matches - 1) * 0.15, 1.0)
        risk_score = calculate_risk_score(raw_score, self.threshold)
        is_valid = raw_score < self.threshold
        
        if not is_valid:
            LOGGER.warning(
                f"Refusal detected in output: {refusal_matches} pattern(s) matched. "
                f"Risk score: {risk_score:.2f}"
            )
        
        return output, is_valid, risk_score
