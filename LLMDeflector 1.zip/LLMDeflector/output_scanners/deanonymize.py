"""Deanonymization scanner."""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

from ..utils import get_logger
from .base import OutputScanner

if TYPE_CHECKING:
    from ..vault import Vault

LOGGER = get_logger(__name__)


class Deanonymize(OutputScanner):
    """
    Deanonymizes placeholders in LLM outputs.
    
    Replaces placeholders with original values from the vault.
    """

    def __init__(self, vault: Vault | None = None):
        """
        Initialize the deanonymize scanner.
        
        Args:
            vault: Vault containing anonymized values.
        """
        self.vault = vault

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Deanonymize placeholders in output."""
        if not output or output.strip() == "" or not self.vault:
            return output, True, 0.0
        
        deanonymized_output = output
        deanonymized_count = 0
        
        # Find all placeholders in output
        placeholder_pattern = r'\[(EMAIL|PHONE|CREDIT_CARD|SSN|IP)_\d+\]'
        placeholders = re.findall(placeholder_pattern, deanonymized_output)
        
        if not placeholders:
            return output, True, 0.0
        
        # Replace placeholders with original values
        for placeholder_match in set(re.findall(r'\[(?:EMAIL|PHONE|CREDIT_CARD|SSN|IP)_\d+\]', output)):
            original_value = self.vault.get_value(placeholder_match)
            if original_value:
                deanonymized_output = deanonymized_output.replace(
                    placeholder_match, original_value
                )
                deanonymized_count += 1
        
        if deanonymized_count > 0:
            LOGGER.info(f"Deanonymized {deanonymized_count} placeholder(s)")
        
        # Always valid, just deanonymizes
        return deanonymized_output, True, 0.0
