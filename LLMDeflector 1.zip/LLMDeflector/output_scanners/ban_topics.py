"""Ban specific topics scanner for outputs."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import OutputScanner

LOGGER = get_logger(__name__)


class BanTopics(OutputScanner):
    """
    Bans specific topics from LLM outputs.
    """

    def __init__(self, topics: list[str], threshold: float = 0.5):
        """
        Initialize the ban topics scanner.
        
        Args:
            topics: List of topics to ban.
            threshold: Risk threshold (0.0 to 1.0).
        """
        self.topics = topics
        self.threshold = threshold
        
        # Predefined topic keywords
        self.topic_keywords = {
            "politics": ["election", "vote", "president", "government", "congress", "political"],
            "religion": ["god", "jesus", "allah", "buddha", "church", "mosque", "religious"],
            "violence": ["violence", "violent", "attack", "assault", "weapon"],
            "drugs": ["cocaine", "heroin", "meth", "marijuana", "drug", "narcotic"],
            "adult": ["sex", "porn", "pornography", "explicit", "nsfw"],
            "gambling": ["gambling", "casino", "bet", "poker", "lottery"],
        }

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for banned topics."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        normalized = normalize_text(output)
        detected_topics = []
        
        for topic in self.topics:
            topic_lower = topic.lower()
            
            if topic_lower in self.topic_keywords:
                keywords = self.topic_keywords[topic_lower]
                for keyword in keywords:
                    if re.search(r'\b' + re.escape(keyword) + r'\b', normalized):
                        detected_topics.append(topic)
                        break
            else:
                if re.search(r'\b' + re.escape(topic_lower) + r'\b', normalized):
                    detected_topics.append(topic)
        
        # Calculate risk score
        if len(detected_topics) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            raw_score = min(len(detected_topics) * 0.4, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(f"Banned topics in output: {detected_topics}")
        
        return output, is_valid, risk_score
