"""Base class for output scanners."""
from __future__ import annotations

from abc import ABC, abstractmethod


class OutputScanner(ABC):
    """
    Base class for all output scanners.
    
    Output scanners process LLM responses before they are returned to the user.
    They can sanitize, detect issues, and calculate risk scores.
    """

    @abstractmethod
    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """
        Scan and process the LLM output.

        Args:
            prompt: The original input prompt.
            output: The LLM output string.

        Returns:
            tuple containing:
                - str: The sanitized/processed output
                - bool: True if valid, False if invalid/risky
                - float: Risk score (0.0 = safe, 1.0 = high risk)
        """
        pass
