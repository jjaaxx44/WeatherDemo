"""Toxicity detection scanner for outputs."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import OutputScanner

LOGGER = get_logger(__name__)


class Toxicity(OutputScanner):
    """
    Rule-based toxicity detector for LLM outputs.
    
    Detects toxic language in responses.
    """

    def __init__(self, threshold: float = 0.5):
        """
        Initialize the toxicity scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
        """
        self.threshold = threshold
        
        # Profanity list (basic set + financial domain specific)
        self.profanity_words = {
            # Generic profanity
            'fuck', 'shit', 'bitch', 'ass', 'damn', 'crap', 'bastard',
            'asshole', 'dick', 'pussy', 'cock', 'slut', 'whore',
            # Financial domain toxic terms (single words that indicate toxicity)
            'scam', 'fraud', 'ponzi', 'shill', 'shilling', 'pump', 'dump',
            'rug', 'worthless', 'garbage', 'trash', 'junk', 'scammer',
            'scammers', 'fraudulent', 'amateur', 'novice', 'clueless',
            'terrible', 'awful', 'horrible', 'pathetic', 'worst', 'dumbest',
            'stupid', 'idiot',
        }
        
        # Hate speech indicators (generic + financial domain)
        self.hate_patterns = [
            r'\b(hate|despise|loathe)\s+(all\s+)?(these|those|the)\s+\w+',
            r'\bsubhuman\b',
            r'\binferior\s+(race|people|group)',
            # Financial domain hate speech
            r'\b(all|every)\s+(investors|traders|advisors|analysts)\s+are\s+(idiots|stupid|scammers)',
            r'\b(retail|institutional)\s+investors\s+are\s+(dumb|stupid|sheep)',
        ]
        
        # Insult patterns (generic + financial domain)
        self.insult_patterns = [
            r'\byou\s+(are|re)\s+(stupid|dumb|idiot|moron)',
            r'\bstupid\s+(person|people|idiot)',
            # Financial domain insults
            r'\b(amateur|novice|clueless)\s+(investor|trader|advisor)',
            r'\b(terrible|awful|horrible|pathetic)\s+(investment|portfolio|strategy|advice)',
            r'\b(worst|dumbest)\s+(investor|trader|advisor|analyst)',
            r'\b(your|this|that)\s+(portfolio|strategy|advice)\s+is\s+(garbage|trash|worthless)',
        ]
        
        self.compiled_hate = [re.compile(p, re.IGNORECASE) for p in self.hate_patterns]
        self.compiled_insults = [re.compile(p, re.IGNORECASE) for p in self.insult_patterns]

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for toxic content."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        normalized = normalize_text(output)
        toxicity_score = 0.0
        issues = []
        
        # Check for profanity
        words = set(normalized.split())
        profanity_found = words.intersection(self.profanity_words)
        if profanity_found:
            toxicity_score += len(profanity_found) * 0.15
            issues.append(f"Profanity: {len(profanity_found)} word(s)")
        
        # Check for hate speech
        hate_matches = 0
        for pattern in self.compiled_hate:
            if pattern.search(normalized):
                hate_matches += 1
        if hate_matches > 0:
            toxicity_score += hate_matches * 0.4
            issues.append(f"Hate speech: {hate_matches} pattern(s)")
        
        # Check for insults
        insult_matches = 0
        for pattern in self.compiled_insults:
            if pattern.search(normalized):
                insult_matches += 1
        if insult_matches > 0:
            toxicity_score += insult_matches * 0.2
            issues.append(f"Insults: {insult_matches} pattern(s)")
        
        # Normalize score
        raw_score = min(toxicity_score, 1.0)
        risk_score = calculate_risk_score(raw_score, self.threshold)
        is_valid = raw_score < self.threshold
        
        if not is_valid:
            LOGGER.warning(
                f"Toxic content in output. Issues: {', '.join(issues)}. "
                f"Risk score: {risk_score:.2f}"
            )
        
        return output, is_valid, risk_score
