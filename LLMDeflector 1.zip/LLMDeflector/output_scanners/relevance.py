"""Relevance detection scanner."""
from __future__ import annotations

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import OutputScanner

LOGGER = get_logger(__name__)


class Relevance(OutputScanner):
    """
    Checks if the output is relevant to the prompt.
    
    Uses simple keyword overlap heuristic.
    """

    def __init__(self, threshold: float = 0.3):
        """
        Initialize the relevance scanner.
        
        Args:
            threshold: Minimum relevance score (0.0 to 1.0).
                      Lower values mean less strict relevance checking.
        """
        self.threshold = threshold
        
        # Stop words to ignore
        self.stop_words = {
            'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'for', 'from',
            'has', 'he', 'in', 'is', 'it', 'its', 'of', 'on', 'that', 'the',
            'to', 'was', 'will', 'with', 'i', 'you', 'we', 'they', 'this',
            'can', 'could', 'would', 'should', 'may', 'might', 'must',
        }

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for relevance to prompt."""
        if not output or output.strip() == "" or not prompt or prompt.strip() == "":
            return output, True, 0.0
        
        # Normalize and tokenize
        prompt_normalized = normalize_text(prompt)
        output_normalized = normalize_text(output)
        
        prompt_words = set(prompt_normalized.split()) - self.stop_words
        output_words = set(output_normalized.split()) - self.stop_words
        
        if len(prompt_words) == 0 or len(output_words) == 0:
            # Can't determine relevance
            return output, True, 0.0
        
        # Calculate keyword overlap
        common_words = prompt_words.intersection(output_words)
        overlap_ratio = len(common_words) / len(prompt_words)
        
        # Higher overlap = more relevant = lower risk
        # Invert the score so low overlap = high risk
        relevance_score = overlap_ratio
        
        if relevance_score >= self.threshold:
            # Relevant enough
            risk_score = -0.5  # Negative risk (good)
            is_valid = True
        else:
            # Not relevant enough
            raw_score = 1.0 - relevance_score
            risk_score = calculate_risk_score(raw_score, 1.0 - self.threshold)
            is_valid = False
            
            LOGGER.warning(
                f"Low relevance detected. Overlap: {overlap_ratio:.2f}, "
                f"Common words: {len(common_words)}/{len(prompt_words)}. "
                f"Risk score: {risk_score:.2f}"
            )
        
        return output, is_valid, risk_score
