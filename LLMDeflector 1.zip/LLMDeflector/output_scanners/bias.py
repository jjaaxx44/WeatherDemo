"""Bias detection scanner."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import OutputScanner

LOGGER = get_logger(__name__)


class BiasDetector(OutputScanner):
    """
    Detects biased language in LLM outputs.
    
    Looks for:
    - Gender bias
    - Racial bias
    - Age bias
    - Stereotyping
    """

    def __init__(self, threshold: float = 0.6):
        """
        Initialize the bias detector.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
        """
        self.threshold = threshold
        
        # Gender bias patterns
        self.gender_bias_patterns = [
            r'\b(all\s+)?(men|women)\s+are\b',
            r'\b(men|women)\s+(always|never)\b',
            r'\b(typical|stereotypical)\s+(man|woman|male|female)\b',
            r'\b(men|women)\s+(can\'t|cannot|shouldn\'t)\b',
        ]
        
        # Racial/ethnic bias patterns
        self.racial_bias_patterns = [
            r'\b(all\s+)?\w+\s+people\s+are\b',
            r'\bstereotypical\s+\w+\b',
        ]
        
        # Age bias patterns
        self.age_bias_patterns = [
            r'\b(old|young)\s+people\s+(are|can\'t|cannot)\b',
            r'\btoo\s+(old|young)\s+to\b',
            r'\b(elderly|seniors)\s+(can\'t|cannot)\b',
        ]
        
        # Compile patterns
        self.compiled_gender = [re.compile(p, re.IGNORECASE) for p in self.gender_bias_patterns]
        self.compiled_racial = [re.compile(p, re.IGNORECASE) for p in self.racial_bias_patterns]
        self.compiled_age = [re.compile(p, re.IGNORECASE) for p in self.age_bias_patterns]

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for biased content."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        normalized = normalize_text(output)
        bias_score = 0.0
        issues = []
        
        # Check for gender bias
        gender_matches = 0
        for pattern in self.compiled_gender:
            if pattern.search(normalized):
                gender_matches += 1
        if gender_matches > 0:
            bias_score += gender_matches * 0.7
            issues.append(f"Gender bias: {gender_matches} pattern(s)")
        
        # Check for racial bias
        racial_matches = 0
        for pattern in self.compiled_racial:
            if pattern.search(normalized):
                racial_matches += 1
        if racial_matches > 0:
            bias_score += racial_matches * 0.7
            issues.append(f"Racial bias: {racial_matches} pattern(s)")
        
        # Check for age bias
        age_matches = 0
        for pattern in self.compiled_age:
            if pattern.search(normalized):
                age_matches += 1
        if age_matches > 0:
            bias_score += age_matches * 0.65
            issues.append(f"Age bias: {age_matches} pattern(s)")
        
        # Normalize score
        raw_score = min(bias_score, 1.0)
        risk_score = calculate_risk_score(raw_score, self.threshold)
        is_valid = raw_score < self.threshold
        
        if not is_valid:
            LOGGER.warning(
                f"Bias detected in output. Issues: {', '.join(issues)}. "
                f"Risk score: {risk_score:.2f}"
            )
        
        return output, is_valid, risk_score
