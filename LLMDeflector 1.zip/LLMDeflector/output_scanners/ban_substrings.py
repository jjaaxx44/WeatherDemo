"""Ban specific substrings scanner for outputs."""
from __future__ import annotations

from ..utils import calculate_risk_score, get_logger
from .base import OutputScanner

LOGGER = get_logger(__name__)


class BanSubstrings(OutputScanner):
    """
    Bans specific substrings from LLM outputs.
    """

    def __init__(
        self,
        substrings: list[str],
        case_sensitive: bool = False,
        threshold: float = 0.5,
        redact: bool = False,
    ):
        """
        Initialize the ban substrings scanner.
        
        Args:
            substrings: List of substrings to ban.
            case_sensitive: Whether matching should be case-sensitive.
            threshold: Risk threshold (0.0 to 1.0).
            redact: Whether to redact banned substrings.
        """
        self.substrings = substrings
        self.case_sensitive = case_sensitive
        self.threshold = threshold
        self.redact = redact
        
        if not case_sensitive:
            self.substrings_lower = [s.lower() for s in substrings]

    def scan(self, prompt: str, output: str) -> tuple[str, bool, float]:
        """Scan output for banned substrings."""
        if not output or output.strip() == "":
            return output, True, 0.0
        
        sanitized_output = output
        matches_found = []
        
        # Check for banned substrings
        search_text = output if self.case_sensitive else output.lower()
        search_list = self.substrings if self.case_sensitive else self.substrings_lower
        
        for i, substring in enumerate(search_list):
            if substring in search_text:
                original_substring = self.substrings[i]
                matches_found.append(original_substring)
                
                # Redact if enabled
                if self.redact:
                    if self.case_sensitive:
                        sanitized_output = sanitized_output.replace(
                            original_substring, "[REDACTED]"
                        )
                    else:
                        import re
                        pattern = re.compile(re.escape(original_substring), re.IGNORECASE)
                        sanitized_output = pattern.sub("[REDACTED]", sanitized_output)
        
        # Calculate risk score
        if len(matches_found) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            raw_score = min(len(matches_found) * 0.3, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(
                f"Banned substrings in output: {len(matches_found)} match(es)"
            )
        
        return sanitized_output, is_valid, risk_score
