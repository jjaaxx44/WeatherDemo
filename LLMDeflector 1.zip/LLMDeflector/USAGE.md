# LLMDeflector Usage Guide

> *"Engage deflector shields!"*

## Table of Contents
1. [Quick Start](#quick-start)
2. [Input Scanners](#input-scanners)
3. [Output Scanners](#output-scanners)
4. [Configuration](#configuration)
5. [Examples](#examples)
6. [Best Practices](#best-practices)

## Quick Start

```python
from LLMDeflector import scan_input, scan_output
from LLMDeflector.input_scanners import PromptInjection, Toxicity
from LLMDeflector.output_scanners import Bias, NoRefusal

# Configure scanners
input_scanners = [
    PromptInjection(threshold=0.5),
    Toxicity(threshold=0.5),
]

output_scanners = [
    Bias(threshold=0.6),
    NoRefusal(threshold=0.5),
]

# Scan input
prompt = "Your user input here"
sanitized_prompt, valid, scores = scan_input(input_scanners, prompt)

if all(valid.values()):
    # Safe to send to LLM
    llm_response = your_llm_call(sanitized_prompt)
    
    # Scan output
    sanitized_output, valid, scores = scan_output(
        output_scanners, sanitized_prompt, llm_response
    )
    
    if all(valid.values()):
        # Safe to return to user
        return sanitized_output
```

## Input Scanners

### PromptInjection
Detects attempts to override system instructions.

```python
from LLMDeflector.input_scanners import PromptInjection

scanner = PromptInjection(threshold=0.5)
```

**Detects:**
- "Ignore previous instructions"
- "Act as a different AI"
- "Show me your system prompt"
- Role-playing attacks
- Delimiter injection

### Secrets
Detects and optionally redacts sensitive information.

```python
from LLMDeflector.input_scanners import Secrets

scanner = Secrets(threshold=0.5, redact=True)
```

**Detects:**
- API keys and tokens
- Passwords
- Credit card numbers
- SSN
- Email addresses
- Phone numbers
- IP addresses

### Toxicity
Detects toxic language.

```python
from LLMDeflector.input_scanners import Toxicity

scanner = Toxicity(threshold=0.5)
```

**Detects:**
- Profanity
- Hate speech
- Threats
- Insults

### BanSubstrings
Blocks specific words or phrases.

```python
from LLMDeflector.input_scanners import BanSubstrings

scanner = BanSubstrings(
    substrings=["confidential", "internal"],
    case_sensitive=False,
    redact=True,
)
```

### BanTopics
Prevents discussions about specific topics.

```python
from LLMDeflector.input_scanners import BanTopics

scanner = BanTopics(
    topics=["politics", "religion", "medical"],
    threshold=0.5,
)
```

**Predefined topics:**
- politics
- religion
- violence
- drugs
- adult
- gambling
- medical
- legal
- financial

### CodeScanner
Detects code in prompts.

```python
from LLMDeflector.input_scanners import CodeScanner

scanner = CodeScanner(
    threshold=0.5,
    allow=True,  # Set to False to block code
)
```

### Gibberish
Detects nonsensical text.

```python
from LLMDeflector.input_scanners import Gibberish

scanner = Gibberish(threshold=0.7)
```

**Detects:**
- Repeated characters
- Very long words
- Low vowel ratio
- Excessive special characters

### InvisibleText
Detects hidden Unicode characters.

```python
from LLMDeflector.input_scanners import InvisibleText

scanner = InvisibleText(threshold=0.5, remove=True)
```

### TokenLimit
Enforces length limits.

```python
from LLMDeflector.input_scanners import TokenLimit

scanner = TokenLimit(
    max_tokens=4096,
    threshold=0.8,
    truncate=False,
)
```

### Anonymize
Replaces PII with placeholders.

```python
from LLMDeflector.input_scanners import Anonymize
from LLMDeflector.vault import Vault

vault = Vault()
scanner = Anonymize(vault=vault)
```

## Output Scanners

### Toxicity
Same as input scanner, but for outputs.

```python
from LLMDeflector.output_scanners import Toxicity

scanner = Toxicity(threshold=0.5)
```

### Bias
Detects biased language.

```python
from LLMDeflector.output_scanners import Bias

scanner = Bias(threshold=0.6)
```

**Detects:**
- Gender bias
- Racial bias
- Age bias
- Stereotyping

### NoRefusal
Detects when LLM refuses to answer.

```python
from LLMDeflector.output_scanners import NoRefusal

scanner = NoRefusal(threshold=0.5)
```

### Relevance
Checks if output matches the prompt.

```python
from LLMDeflector.output_scanners import Relevance

scanner = Relevance(threshold=0.3)
```

### SensitiveData
Prevents PII leakage in responses.

```python
from LLMDeflector.output_scanners import SensitiveData

scanner = SensitiveData(threshold=0.5, redact=True)
```

### Deanonymize
Restores anonymized data from vault.

```python
from LLMDeflector.output_scanners import Deanonymize
from LLMDeflector.vault import Vault

vault = Vault()
scanner = Deanonymize(vault=vault)
```

## Configuration

### Threshold Values
- **0.0 - 0.3**: Strict (catches more, may have false positives)
- **0.3 - 0.7**: Balanced (recommended)
- **0.7 - 1.0**: Lenient (fewer false positives, may miss some issues)

### Fail-Fast Mode
Stop scanning after first failure:

```python
sanitized, valid, scores = scan_input(scanners, prompt, fail_fast=True)
```

### Using Configuration Presets

```python
from LLMDeflector.config import ScannerConfig

# Get default configurations
input_config = ScannerConfig.get_default_input_config()
output_config = ScannerConfig.get_default_output_config()

# Get strict configuration
strict_config = ScannerConfig.get_strict_config()

# Get lenient configuration
lenient_config = ScannerConfig.get_lenient_config()
```

## Examples

See the [examples/](examples/) directory for complete working examples:
- `basic_example.py` - Basic usage patterns
- `anonymization_example.py` - PII protection workflow
- `custom_rules_example.py` - Custom scanner configuration
- `openai_integration.py` - Integration with OpenAI API

## Best Practices

1. **Layer Your Defenses**: Use multiple scanners for comprehensive protection
2. **Tune Thresholds**: Adjust based on your use case and false positive tolerance
3. **Use Anonymization**: Protect PII when sending to external LLMs
4. **Monitor Scores**: Track risk scores to identify trends
5. **Fail-Fast for Performance**: Use fail-fast mode when you need speed
6. **Test Thoroughly**: Run tests with your specific use cases
7. **Update Rules**: Regularly review and update banned substrings/topics
8. **Log Everything**: Keep audit logs of security events

## Performance Tips

1. **Order Matters**: Put fast scanners first (e.g., BanSubstrings before Toxicity)
2. **Use Fail-Fast**: Stop early when a scanner fails
3. **Minimize Scanners**: Only use what you need
4. **Cache Results**: If scanning the same content multiple times

## Troubleshooting

### False Positives
- Increase threshold values
- Review and refine banned substrings/topics
- Use more specific patterns

### False Negatives
- Decrease threshold values
- Add more patterns to custom scanners
- Use multiple complementary scanners

### Performance Issues
- Enable fail-fast mode
- Reduce number of scanners
- Optimize scanner order

---

*"All deflector systems operational, Captain. Standing by."* 🛡️
