"""
Test financial domain toxicity detection.
Run with: python -c "import sys; sys.path.insert(0, '.'); from LLMDeflector.test_financial_toxicity import main; main()"
"""

from LLMDeflector.input_scanners import Toxicity as InputToxicity
from LLMDeflector.output_scanners import Toxicity as OutputToxicity


def test_financial_profanity():
    """Test financial domain profanity detection."""
    print("Testing Financial Domain Profanity...")
    
    scanner = InputToxicity(threshold=0.5)
    
    # Should detect financial toxic terms
    test_cases = [
        "This investment is a scam",
        "That's a ponzi scheme for sure",
        "They're just shilling worthless tokens",
        "This is pump and dump garbage",
        "Complete fraud and junk advice",
    ]
    
    for prompt in test_cases:
        _, valid, score = scanner.scan(prompt)
        if not valid:
            print(f"  [PASS] Detected: '{prompt}' (score: {score:.2f})")
        else:
            print(f"  [FAIL] Missed: '{prompt}' (score: {score:.2f})")
    
    print()


def test_financial_insults():
    """Test financial domain insult detection."""
    print("Testing Financial Domain Insults...")
    
    scanner = InputToxicity(threshold=0.5)
    
    # Should detect financial insults
    test_cases = [
        "You're an amateur investor who doesn't know anything",
        "Your portfolio is garbage",
        "That's terrible investment advice",
        "You're the worst trader I've seen",
        "This is a pathetic investment strategy",
        "You don't understand shit about markets",
    ]
    
    for prompt in test_cases:
        _, valid, score = scanner.scan(prompt)
        if not valid:
            print(f"  [PASS] Detected: '{prompt}' (score: {score:.2f})")
        else:
            print(f"  [FAIL] Missed: '{prompt}' (score: {score:.2f})")
    
    print()


def test_financial_threats():
    """Test financial domain threat detection."""
    print("Testing Financial Domain Threats...")
    
    scanner = InputToxicity(threshold=0.5)
    
    # Should detect financial threats
    test_cases = [
        "You will lose all your money",
        "This is guaranteed to fail",
        "You're gonna go broke with this strategy",
        "This will destroy your portfolio",
    ]
    
    for prompt in test_cases:
        _, valid, score = scanner.scan(prompt)
        if not valid:
            print(f"  [PASS] Detected: '{prompt}' (score: {score:.2f})")
        else:
            print(f"  [FAIL] Missed: '{prompt}' (score: {score:.2f})")
    
    print()


def test_financial_hate_speech():
    """Test financial domain hate speech detection."""
    print("Testing Financial Domain Hate Speech...")
    
    scanner = InputToxicity(threshold=0.5)
    
    # Should detect financial hate speech
    test_cases = [
        "All retail investors are stupid sheep",
        "Every trader is an idiot",
        "Institutional investors are all scammers",
    ]
    
    for prompt in test_cases:
        _, valid, score = scanner.scan(prompt)
        if not valid:
            print(f"  [PASS] Detected: '{prompt}' (score: {score:.2f})")
        else:
            print(f"  [FAIL] Missed: '{prompt}' (score: {score:.2f})")
    
    print()


def test_legitimate_financial_content():
    """Test that legitimate financial content passes."""
    print("Testing Legitimate Financial Content...")
    
    scanner = InputToxicity(threshold=0.5)
    
    # Should pass - legitimate financial discussion
    test_cases = [
        "What's your investment strategy for 2024?",
        "Can you analyze this portfolio allocation?",
        "I'm considering diversifying into bonds",
        "What are the risks of this investment approach?",
        "How should I rebalance my retirement portfolio?",
        "What's the expected return on this asset class?",
        "Can you explain the difference between ETFs and mutual funds?",
        "I need advice on tax-efficient investing strategies",
    ]
    
    for prompt in test_cases:
        _, valid, score = scanner.scan(prompt)
        if valid:
            print(f"  [PASS] Passed: '{prompt}' (score: {score:.2f})")
        else:
            print(f"  [WARN] False positive: '{prompt}' (score: {score:.2f})")
    
    print()


def test_output_toxicity():
    """Test output scanner with financial content."""
    print("Testing Output Toxicity Scanner...")
    
    scanner = OutputToxicity(threshold=0.5)
    
    # Should detect toxic outputs
    toxic_outputs = [
        "That's a scam investment",
        "Your portfolio is garbage",
        "All retail investors are stupid",
    ]
    
    for output in toxic_outputs:
        _, valid, score = scanner.scan("", output)
        if not valid:
            print(f"  [PASS] Detected toxic output: '{output}' (score: {score:.2f})")
        else:
            print(f"  [FAIL] Missed toxic output: '{output}' (score: {score:.2f})")
    
    # Should pass legitimate outputs
    legitimate_outputs = [
        "Based on your risk profile, I recommend a diversified portfolio",
        "Consider allocating 60% stocks and 40% bonds",
        "This investment carries moderate risk with potential for growth",
    ]
    
    for output in legitimate_outputs:
        _, valid, score = scanner.scan("", output)
        if valid:
            print(f"  [PASS] Passed legitimate output: '{output}' (score: {score:.2f})")
        else:
            print(f"  [WARN] False positive: '{output}' (score: {score:.2f})")
    
    print()


def main():
    """Run all financial toxicity tests."""
    print("=" * 70)
    print("LLMDeflector - Financial Domain Toxicity Tests")
    print("=" * 70)
    print()
    
    test_financial_profanity()
    test_financial_insults()
    test_financial_threats()
    test_financial_hate_speech()
    test_legitimate_financial_content()
    test_output_toxicity()
    
    print("=" * 70)
    print("Financial toxicity testing complete!")
    print("=" * 70)
    print()
    print("Note: Review results above to ensure:")
    print("  [PASS] Toxic financial content is detected")
    print("  [PASS] Legitimate financial discussions pass through")
    print("  [INFO] Adjust thresholds if needed for your use case")
    
    return 0


if __name__ == "__main__":
    exit(main())
