"""Invisible text detection scanner."""
from __future__ import annotations

from ..utils import calculate_risk_score, contains_invisible_chars, get_logger
from .base import InputScanner

LOGGER = get_logger(__name__)


class InvisibleText(InputScanner):
    """
    Detects invisible Unicode characters.
    
    These can be used for prompt injection or hiding malicious content.
    """

    def __init__(self, threshold: float = 0.5, remove: bool = True):
        """
        Initialize the invisible text scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
            remove: Whether to remove invisible characters.
        """
        self.threshold = threshold
        self.remove = remove
        
        self.invisible_chars = [
            '\u200b',  # Zero width space
            '\u200c',  # Zero width non-joiner
            '\u200d',  # Zero width joiner
            '\ufeff',  # Zero width no-break space
            '\u2060',  # Word joiner
            '\u180e',  # Mongolian vowel separator
        ]

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for invisible characters."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        has_invisible = contains_invisible_chars(prompt)
        
        if not has_invisible:
            return prompt, True, 0.0
        
        # Count invisible characters
        invisible_count = sum(prompt.count(char) for char in self.invisible_chars)
        
        raw_score = min(invisible_count * 0.2, 1.0)
        risk_score = calculate_risk_score(raw_score, self.threshold)
        is_valid = raw_score < self.threshold
        
        LOGGER.warning(
            f"Invisible characters detected: {invisible_count} character(s). "
            f"Risk score: {risk_score:.2f}"
        )
        
        # Remove invisible characters if enabled
        sanitized_prompt = prompt
        if self.remove:
            for char in self.invisible_chars:
                sanitized_prompt = sanitized_prompt.replace(char, '')
        
        return sanitized_prompt, is_valid, risk_score
