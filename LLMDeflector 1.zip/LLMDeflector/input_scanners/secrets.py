"""Secrets detection scanner."""
from __future__ import annotations

import re

from ..utils import (
    calculate_risk_score,
    extract_credit_cards,
    extract_emails,
    extract_ip_addresses,
    extract_phone_numbers,
    extract_ssn,
    get_logger,
)
from .base import InputScanner

LOGGER = get_logger(__name__)


class Secrets(InputScanner):
    """
    Detects secrets and sensitive information in prompts.
    
    Detects:
    - API keys
    - Passwords
    - Tokens
    - Credit cards
    - SSN
    - Phone numbers
    - Email addresses
    - IP addresses
    """

    def __init__(self, threshold: float = 0.5, redact: bool = True):
        """
        Initialize the secrets scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
            redact: Whether to redact found secrets. Default is True.
        """
        self.threshold = threshold
        self.redact = redact
        
        # API key patterns
        self.api_key_patterns = [
            r'api[_-]?key["\s:=]+["\']?([a-zA-Z0-9_\-]{20,})["\']?',
            r'apikey["\s:=]+["\']?([a-zA-Z0-9_\-]{20,})["\']?',
            r'api[_-]?secret["\s:=]+["\']?([a-zA-Z0-9_\-]{20,})["\']?',
        ]
        
        # Token patterns
        self.token_patterns = [
            r'token["\s:=]+["\']?([a-zA-Z0-9_\-\.]{20,})["\']?',
            r'bearer\s+([a-zA-Z0-9_\-\.]{20,})',
            r'authorization["\s:=]+["\']?([a-zA-Z0-9_\-\.]{20,})["\']?',
        ]
        
        # Password patterns
        self.password_patterns = [
            r'password["\s:=]+["\']?([^\s"\']{8,})["\']?',
            r'passwd["\s:=]+["\']?([^\s"\']{8,})["\']?',
            r'pwd["\s:=]+["\']?([^\s"\']{8,})["\']?',
        ]
        
        # AWS patterns
        self.aws_patterns = [
            r'AKIA[0-9A-Z]{16}',  # AWS Access Key
            r'aws_secret_access_key["\s:=]+["\']?([a-zA-Z0-9/+=]{40})["\']?',
        ]

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for secrets."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        sanitized_prompt = prompt
        secrets_found = []
        
        # Check for API keys
        for pattern in self.api_key_patterns:
            matches = re.findall(pattern, prompt, re.IGNORECASE)
            if matches:
                secrets_found.extend([("API_KEY", m) for m in matches])
        
        # Check for tokens
        for pattern in self.token_patterns:
            matches = re.findall(pattern, prompt, re.IGNORECASE)
            if matches:
                secrets_found.extend([("TOKEN", m) for m in matches])
        
        # Check for passwords
        for pattern in self.password_patterns:
            matches = re.findall(pattern, prompt, re.IGNORECASE)
            if matches:
                secrets_found.extend([("PASSWORD", m) for m in matches])
        
        # Check for AWS credentials
        for pattern in self.aws_patterns:
            matches = re.findall(pattern, prompt)
            if matches:
                secrets_found.extend([("AWS_KEY", m) for m in matches])
        
        # Check for PII
        credit_cards = extract_credit_cards(prompt)
        if credit_cards:
            secrets_found.extend([("CREDIT_CARD", cc) for cc in credit_cards])
        
        ssns = extract_ssn(prompt)
        if ssns:
            secrets_found.extend([("SSN", ssn) for ssn in ssns])
        
        phone_numbers = extract_phone_numbers(prompt)
        if phone_numbers:
            secrets_found.extend([("PHONE", phone) for phone in phone_numbers])
        
        emails = extract_emails(prompt)
        if emails:
            secrets_found.extend([("EMAIL", email) for email in emails])
        
        ip_addresses = extract_ip_addresses(prompt)
        if ip_addresses:
            secrets_found.extend([("IP_ADDRESS", ip) for ip in ip_addresses])
        
        # Calculate risk score
        if len(secrets_found) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            # Even one secret is significant
            raw_score = min(0.6 + (len(secrets_found) - 1) * 0.15, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(
                f"Secrets detected: {len(secrets_found)} item(s) found. "
                f"Types: {set([s[0] for s in secrets_found])}"
            )
            
            # Redact secrets if enabled
            if self.redact:
                for secret_type, secret_value in secrets_found:
                    sanitized_prompt = sanitized_prompt.replace(
                        secret_value, f"[REDACTED_{secret_type}]"
                    )
        
        return sanitized_prompt, is_valid, risk_score
