"""Base class for input scanners."""
from __future__ import annotations

from abc import ABC, abstractmethod


class InputScanner(ABC):
    """
    Base class for all input scanners.
    
    Input scanners process prompts before they are sent to the LLM.
    They can sanitize, detect issues, and calculate risk scores.
    """

    @abstractmethod
    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """
        Scan and process the input prompt.

        Args:
            prompt: The input prompt string.

        Returns:
            tuple containing:
                - str: The sanitized/processed prompt
                - bool: True if valid, False if invalid/risky
                - float: Risk score (0.0 = safe, 1.0 = high risk)
        """
        pass
