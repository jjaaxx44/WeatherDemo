"""Ban specific topics scanner."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import InputScanner

LOGGER = get_logger(__name__)


class BanTopics(InputScanner):
    """
    Bans specific topics from prompts using keyword matching.
    
    Useful for preventing discussions about sensitive topics.
    """

    def __init__(self, topics: list[str], threshold: float = 0.5):
        """
        Initialize the ban topics scanner.
        
        Args:
            topics: List of topics to ban (e.g., ["politics", "religion"]).
            threshold: Risk threshold (0.0 to 1.0).
        """
        self.topics = topics
        self.threshold = threshold
        
        # Predefined topic keywords
        self.topic_keywords = {
            "politics": ["election", "vote", "president", "government", "congress", "senate", "political", "democrat", "republican"],
            "religion": ["god", "jesus", "allah", "buddha", "church", "mosque", "temple", "prayer", "religious", "faith"],
            "violence": ["violence", "violent", "attack", "assault", "murder", "kill", "weapon", "gun", "bomb"],
            "drugs": ["cocaine", "heroin", "meth", "marijuana", "drug", "narcotic", "substance abuse"],
            "adult": ["sex", "porn", "pornography", "explicit", "nsfw", "adult content"],
            "gambling": ["gambling", "casino", "bet", "poker", "lottery", "wager"],
            "medical": ["diagnosis", "treatment", "medication", "prescription", "medical advice", "doctor"],
            "legal": ["legal advice", "lawsuit", "attorney", "lawyer", "court", "sue"],
            "financial": ["investment advice", "stock tip", "financial advice", "trading advice"],
        }

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for banned topics."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        normalized = normalize_text(prompt)
        detected_topics = []
        
        for topic in self.topics:
            topic_lower = topic.lower()
            
            # Check if topic is in predefined keywords
            if topic_lower in self.topic_keywords:
                keywords = self.topic_keywords[topic_lower]
                for keyword in keywords:
                    if re.search(r'\b' + re.escape(keyword) + r'\b', normalized):
                        detected_topics.append(topic)
                        break
            else:
                # Direct topic name matching
                if re.search(r'\b' + re.escape(topic_lower) + r'\b', normalized):
                    detected_topics.append(topic)
        
        # Calculate risk score
        if len(detected_topics) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            raw_score = min(len(detected_topics) * 0.4, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(
                f"Banned topics detected: {detected_topics}. "
                f"Risk score: {risk_score:.2f}"
            )
        
        return prompt, is_valid, risk_score
