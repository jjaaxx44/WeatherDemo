"""Token limit scanner."""
from __future__ import annotations

from ..utils import calculate_risk_score, count_words, get_logger
from .base import InputScanner

LOGGER = get_logger(__name__)


class TokenLimit(InputScanner):
    """
    Enforces token/word limits on prompts.
    
    Prevents excessively long prompts that could:
    - Cause availability issues
    - Increase costs
    - Be used for DoS attacks
    """

    def __init__(
        self,
        max_tokens: int = 4096,
        threshold: float = 0.8,
        truncate: bool = False,
    ):
        """
        Initialize the token limit scanner.
        
        Args:
            max_tokens: Maximum number of tokens (approximated by words).
            threshold: Threshold as fraction of max_tokens (0.0 to 1.0).
            truncate: Whether to truncate prompts that exceed the limit.
        """
        self.max_tokens = max_tokens
        self.threshold = threshold
        self.truncate = truncate

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for token limit."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        # Approximate tokens by word count (rough estimate)
        # Real tokenization would require a tokenizer library
        word_count = count_words(prompt)
        
        # Calculate how close we are to the limit
        usage_ratio = word_count / self.max_tokens
        
        if usage_ratio < self.threshold:
            # Well within limits
            risk_score = calculate_risk_score(usage_ratio, self.threshold)
            return prompt, True, risk_score
        
        # Approaching or exceeding limit
        is_valid = usage_ratio < 1.0
        risk_score = calculate_risk_score(usage_ratio, self.threshold)
        
        if not is_valid:
            LOGGER.warning(
                f"Token limit exceeded: {word_count} words (max: {self.max_tokens}). "
                f"Risk score: {risk_score:.2f}"
            )
        else:
            LOGGER.warning(
                f"Approaching token limit: {word_count} words (max: {self.max_tokens}). "
                f"Risk score: {risk_score:.2f}"
            )
        
        # Truncate if enabled and exceeded
        sanitized_prompt = prompt
        if self.truncate and not is_valid:
            words = prompt.split()
            truncated_words = words[:self.max_tokens]
            sanitized_prompt = ' '.join(truncated_words)
            LOGGER.info(f"Prompt truncated to {self.max_tokens} words")
        
        return sanitized_prompt, is_valid, risk_score
