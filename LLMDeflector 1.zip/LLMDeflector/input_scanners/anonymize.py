"""Anonymization scanner."""
from __future__ import annotations

from typing import TYPE_CHECKING

from ..utils import (
    extract_credit_cards,
    extract_emails,
    extract_ip_addresses,
    extract_phone_numbers,
    extract_ssn,
    get_logger,
)
from .base import InputScanner

if TYPE_CHECKING:
    from ..vault import Vault

LOGGER = get_logger(__name__)


class Anonymize(InputScanner):
    """
    Anonymizes PII in prompts.
    
    Replaces sensitive information with placeholders and stores
    the original values in a vault for later deanonymization.
    """

    def __init__(self, vault: Vault | None = None):
        """
        Initialize the anonymize scanner.
        
        Args:
            vault: Vault to store anonymized values for deanonymization.
        """
        self.vault = vault

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan and anonymize PII in prompt."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        sanitized_prompt = prompt
        anonymized_count = 0
        
        # Anonymize emails
        emails = extract_emails(prompt)
        for i, email in enumerate(emails):
            placeholder = f"[EMAIL_{i+1}]"
            sanitized_prompt = sanitized_prompt.replace(email, placeholder)
            if self.vault:
                self.vault.append((placeholder, email))
            anonymized_count += 1
        
        # Anonymize phone numbers
        phones = extract_phone_numbers(prompt)
        for i, phone in enumerate(phones):
            placeholder = f"[PHONE_{i+1}]"
            sanitized_prompt = sanitized_prompt.replace(phone, placeholder)
            if self.vault:
                self.vault.append((placeholder, phone))
            anonymized_count += 1
        
        # Anonymize credit cards
        credit_cards = extract_credit_cards(prompt)
        for i, cc in enumerate(credit_cards):
            placeholder = f"[CREDIT_CARD_{i+1}]"
            sanitized_prompt = sanitized_prompt.replace(cc, placeholder)
            if self.vault:
                self.vault.append((placeholder, cc))
            anonymized_count += 1
        
        # Anonymize SSN
        ssns = extract_ssn(prompt)
        for i, ssn in enumerate(ssns):
            placeholder = f"[SSN_{i+1}]"
            sanitized_prompt = sanitized_prompt.replace(ssn, placeholder)
            if self.vault:
                self.vault.append((placeholder, ssn))
            anonymized_count += 1
        
        # Anonymize IP addresses
        ips = extract_ip_addresses(prompt)
        for i, ip in enumerate(ips):
            placeholder = f"[IP_{i+1}]"
            sanitized_prompt = sanitized_prompt.replace(ip, placeholder)
            if self.vault:
                self.vault.append((placeholder, ip))
            anonymized_count += 1
        
        if anonymized_count > 0:
            LOGGER.info(f"Anonymized {anonymized_count} PII item(s)")
        
        # Always valid, just anonymizes
        return sanitized_prompt, True, 0.0
