"""Gibberish detection scanner."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger
from .base import InputScanner

LOGGER = get_logger(__name__)


class Gibberish(InputScanner):
    """
    Detects gibberish or nonsensical text.
    
    Uses heuristics like:
    - Excessive repeated characters
    - Very long words
    - Low vowel ratio
    - Random character sequences
    """

    def __init__(self, threshold: float = 0.7):
        """
        Initialize the gibberish scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0). Higher threshold = more lenient.
        """
        self.threshold = threshold

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for gibberish."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        gibberish_score = 0.0
        
        # Check for excessive repeated characters
        repeated_char_pattern = r'(.)\1{4,}'  # Same char repeated 5+ times
        repeated_matches = re.findall(repeated_char_pattern, prompt)
        if repeated_matches:
            gibberish_score += min(len(repeated_matches) * 0.2, 0.4)
        
        # Check for very long words (likely gibberish)
        words = prompt.split()
        long_words = [w for w in words if len(w) > 20]
        if long_words:
            gibberish_score += min(len(long_words) * 0.15, 0.3)
        
        # Check vowel ratio (gibberish often has low vowel ratio)
        alpha_chars = [c for c in prompt.lower() if c.isalpha()]
        if alpha_chars:
            vowels = [c for c in alpha_chars if c in 'aeiou']
            vowel_ratio = len(vowels) / len(alpha_chars)
            
            # Normal English has ~40% vowels
            if vowel_ratio < 0.15:  # Very low vowel ratio
                gibberish_score += 0.3
            elif vowel_ratio < 0.25:  # Low vowel ratio
                gibberish_score += 0.15
        
        # Check for excessive special characters
        special_chars = [c for c in prompt if not c.isalnum() and not c.isspace()]
        if len(prompt) > 0:
            special_ratio = len(special_chars) / len(prompt)
            if special_ratio > 0.3:
                gibberish_score += 0.2
        
        # Normalize score
        raw_score = min(gibberish_score, 1.0)
        risk_score = calculate_risk_score(raw_score, self.threshold)
        is_valid = raw_score < self.threshold
        
        if not is_valid:
            LOGGER.warning(
                f"Gibberish detected. Score: {raw_score:.2f}, "
                f"Risk score: {risk_score:.2f}"
            )
        
        return prompt, is_valid, risk_score
