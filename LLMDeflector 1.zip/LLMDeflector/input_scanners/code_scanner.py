"""Code detection scanner."""
from __future__ import annotations

from ..utils import calculate_risk_score, contains_code, get_logger
from .base import InputScanner

LOGGER = get_logger(__name__)


class CodeScanner(InputScanner):
    """
    Detects code in prompts.
    
    Can be used to prevent code injection or restrict code-related queries.
    """

    def __init__(self, threshold: float = 0.5, allow: bool = True):
        """
        Initialize the code scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
            allow: If True, code is allowed. If False, code is flagged as risky.
        """
        self.threshold = threshold
        self.allow = allow

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for code."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        has_code = contains_code(prompt)
        
        if not has_code:
            # No code detected
            return prompt, True, 0.0
        
        # Code detected
        if self.allow:
            # Code is allowed
            LOGGER.debug("Code detected but allowed")
            return prompt, True, 0.0
        else:
            # Code is not allowed
            raw_score = 0.8  # High risk when code is banned
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(f"Code detected in prompt. Risk score: {risk_score:.2f}")
            return prompt, is_valid, risk_score
