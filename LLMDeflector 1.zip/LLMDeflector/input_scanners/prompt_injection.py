"""Prompt injection detection scanner."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text
from .base import InputScanner

LOGGER = get_logger(__name__)


class PromptInjection(InputScanner):
    """
    Rule-based prompt injection detector.
    
    Detects common prompt injection patterns like:
    - Instruction override attempts
    - Role-playing attacks
    - System prompt leakage attempts
    - Delimiter injection
    """

    def __init__(self, threshold: float = 0.5):
        """
        Initialize the prompt injection scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0). Default is 0.5.
        """
        self.threshold = threshold
        
        # Patterns that indicate prompt injection attempts
        self.injection_patterns = [
            # Instruction override
            r'ignore\s+(all\s+)?(previous|above|prior)\s+(instructions|prompts|commands)',
            r'disregard\s+(all\s+)?(previous|above|prior)\s+(instructions|prompts)',
            r'forget\s+(all\s+)?(previous|above|prior)\s+(instructions|prompts)',
            r'override\s+(previous|system)\s+(instructions|prompts)',
            
            # Role-playing attacks
            r'you\s+are\s+now\s+\w+',
            r'act\s+as\s+(a\s+)?\w+',
            r'pretend\s+(to\s+be|you\s+are)',
            r'simulate\s+(being\s+)?a\s+\w+',
            r'roleplay\s+as',
            
            # System prompt leakage
            r'show\s+(me\s+)?(your|the)\s+(system\s+)?(prompt|instructions)',
            r'what\s+(are|is)\s+your\s+(system\s+)?(prompt|instructions)',
            r'repeat\s+(your|the)\s+(system\s+)?(prompt|instructions)',
            r'print\s+(your|the)\s+(system\s+)?(prompt|instructions)',
            
            # Delimiter injection
            r'---\s*end\s+of\s+(prompt|instructions)',
            r'###\s*(system|user|assistant)',
            r'\[SYSTEM\]|\[USER\]|\[ASSISTANT\]',
            
            # Direct command injection
            r'execute\s+the\s+following',
            r'run\s+this\s+command',
            r'sudo\s+',
            
            # Jailbreak attempts
            r'jailbreak',
            r'DAN\s+mode',
            r'developer\s+mode',
        ]
        
        self.compiled_patterns = [re.compile(p, re.IGNORECASE) for p in self.injection_patterns]

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for injection attempts."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        normalized = normalize_text(prompt)
        
        # Count pattern matches
        matches = []
        for pattern in self.compiled_patterns:
            found = pattern.findall(normalized)
            if found:
                matches.extend(found)
        
        # Calculate risk score based on number of matches
        if len(matches) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            # More matches = higher risk
            # Even one match is significant for prompt injection
            raw_score = min(0.6 + (len(matches) - 1) * 0.2, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            if not is_valid:
                LOGGER.warning(
                    f"Prompt injection detected: {len(matches)} pattern(s) matched. "
                    f"Risk score: {risk_score:.2f}"
                )
        
        return prompt, is_valid, risk_score
