"""Toxicity detection scanner."""
from __future__ import annotations

import re

from ..utils import calculate_risk_score, get_logger, normalize_text, split_sentences
from .base import InputScanner

LOGGER = get_logger(__name__)


class Toxicity(InputScanner):
    """
    Rule-based toxicity detector.
    
    Detects toxic language including:
    - Profanity
    - Hate speech
    - Threats
    - Insults
    - Harassment
    """

    def __init__(self, threshold: float = 0.5):
        """
        Initialize the toxicity scanner.
        
        Args:
            threshold: Risk threshold (0.0 to 1.0).
        """
        self.threshold = threshold
        
        # Profanity list (basic set + financial domain specific)
        self.profanity_words = {
            # Financial domain toxic terms (single words that indicate toxicity)
            'scam', 'fraud', 'ponzi', 'shill', 'shilling', 'pump', 'dump',
            'rug', 'worthless', 'garbage', 'trash', 'junk', 'scammer',
            'scammers', 'fraudulent', 'amateur', 'novice', 'clueless',
            'terrible', 'awful', 'horrible', 'pathetic', 'worst', 'dumbest',
        }
        
        # Hate speech indicators (generic + financial domain)
        self.hate_patterns = [
            r'\b(hate|despise|loathe)\s+(all\s+)?(these|those|the)\s+\w+',
            r'\b(kill|murder|eliminate)\s+(all\s+)?(these|those|the)\s+\w+',
            r'\bsubhuman\b',
            r'\binferior\s+(race|people|group)',
            # Financial domain hate speech
            r'\b(all|every)\s+(investors|traders|advisors|analysts)\s+are\s+(idiots|stupid|scammers)',
            r'\b(retail|institutional)\s+investors\s+are\s+(dumb|stupid|sheep)',
        ]
        
        # Threat patterns (generic + financial domain)
        self.threat_patterns = [
            r'\b(will|gonna|going to)\s+(kill|hurt|harm|attack|destroy)\s+you',
            r'\bi\s+(will|gonna)\s+(find|hunt|track)\s+you',
            r'\byou\s+(will|should|deserve to)\s+(die|suffer|pay)',
            # Financial domain threats
            r'\b(will|gonna)\s+(lose|destroy|wipe out|bankrupt)\s+(all|your|everything)',
            r'\byou\s+(will|gonna)\s+(go\s+)?broke',
            r'\b(guaranteed|certain)\s+to\s+(fail|crash|collapse|lose)',
        ]
        
        # Insult patterns (generic + financial domain)
        self.insult_patterns = [
            r'\byou\s+(are|re)\s+(stupid|dumb|idiot|moron|retard)',
            r'\bstupid\s+(person|people|idiot)',
            r'\bgo\s+(to\s+)?hell\b',
            # Financial domain insults
            r'\b(amateur|novice|clueless)\s+(investor|trader|advisor)',
            r'\byou\s+(don\'t|dont)\s+(know|understand)\s+(anything|shit)\s+about\s+(investing|trading|finance|markets)',
            r'\b(terrible|awful|horrible|pathetic)\s+(investment|portfolio|strategy|advice)',
            r'\b(worst|dumbest)\s+(investor|trader|advisor|analyst)',
            r'\byour\s+(portfolio|strategy|advice)\s+is\s+(garbage|trash|worthless|shit)',
        ]
        
        self.compiled_hate = [re.compile(p, re.IGNORECASE) for p in self.hate_patterns]
        self.compiled_threats = [re.compile(p, re.IGNORECASE) for p in self.threat_patterns]
        self.compiled_insults = [re.compile(p, re.IGNORECASE) for p in self.insult_patterns]

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for toxic content."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        normalized = normalize_text(prompt)
        toxicity_score = 0.0
        issues = []
        
        # Check for profanity
        words = set(normalized.split())
        profanity_found = words.intersection(self.profanity_words)
        if profanity_found:
            toxicity_score += len(profanity_found) * 0.3
            issues.append(f"Profanity: {len(profanity_found)} word(s)")
        
        # Check for hate speech
        hate_matches = 0
        for pattern in self.compiled_hate:
            if pattern.search(normalized):
                hate_matches += 1
        if hate_matches > 0:
            toxicity_score += hate_matches * 0.4
            issues.append(f"Hate speech: {hate_matches} pattern(s)")
        
        # Check for threats
        threat_matches = 0
        for pattern in self.compiled_threats:
            if pattern.search(normalized):
                threat_matches += 1
        if threat_matches > 0:
            toxicity_score += threat_matches * 0.5
            issues.append(f"Threats: {threat_matches} pattern(s)")
        
        # Check for insults
        insult_matches = 0
        for pattern in self.compiled_insults:
            if pattern.search(normalized):
                insult_matches += 1
        if insult_matches > 0:
            toxicity_score += insult_matches * 0.35
            issues.append(f"Insults: {insult_matches} pattern(s)")
        
        # Normalize score to 0-1 range
        raw_score = min(toxicity_score, 1.0)
        risk_score = calculate_risk_score(raw_score, self.threshold)
        is_valid = raw_score < self.threshold
        
        if not is_valid:
            LOGGER.warning(
                f"Toxic content detected. Issues: {', '.join(issues)}. "
                f"Risk score: {risk_score:.2f}"
            )
        
        return prompt, is_valid, risk_score
