"""Ban specific substrings scanner."""
from __future__ import annotations

from ..utils import calculate_risk_score, get_logger
from .base import InputScanner

LOGGER = get_logger(__name__)


class BanSubstrings(InputScanner):
    """
    Bans specific substrings from prompts.
    
    Useful for blocking specific words, phrases, or patterns.
    """

    def __init__(
        self,
        substrings: list[str],
        case_sensitive: bool = False,
        threshold: float = 0.5,
        redact: bool = False,
    ):
        """
        Initialize the ban substrings scanner.
        
        Args:
            substrings: List of substrings to ban.
            case_sensitive: Whether matching should be case-sensitive.
            threshold: Risk threshold (0.0 to 1.0).
            redact: Whether to redact banned substrings instead of failing.
        """
        self.substrings = substrings
        self.case_sensitive = case_sensitive
        self.threshold = threshold
        self.redact = redact
        
        if not case_sensitive:
            self.substrings_lower = [s.lower() for s in substrings]

    def scan(self, prompt: str) -> tuple[str, bool, float]:
        """Scan prompt for banned substrings."""
        if not prompt or prompt.strip() == "":
            return prompt, True, 0.0
        
        sanitized_prompt = prompt
        matches_found = []
        
        # Check for banned substrings
        search_text = prompt if self.case_sensitive else prompt.lower()
        search_list = self.substrings if self.case_sensitive else self.substrings_lower
        
        for i, substring in enumerate(search_list):
            if substring in search_text:
                original_substring = self.substrings[i]
                matches_found.append(original_substring)
                
                # Redact if enabled
                if self.redact:
                    if self.case_sensitive:
                        sanitized_prompt = sanitized_prompt.replace(
                            original_substring, "[REDACTED]"
                        )
                    else:
                        # Case-insensitive replacement
                        import re
                        pattern = re.compile(re.escape(original_substring), re.IGNORECASE)
                        sanitized_prompt = pattern.sub("[REDACTED]", sanitized_prompt)
        
        # Calculate risk score
        if len(matches_found) == 0:
            risk_score = 0.0
            is_valid = True
        else:
            # Even one banned substring is significant
            raw_score = min(0.7 + (len(matches_found) - 1) * 0.15, 1.0)
            risk_score = calculate_risk_score(raw_score, self.threshold)
            is_valid = raw_score < self.threshold
            
            LOGGER.warning(
                f"Banned substrings detected: {len(matches_found)} match(es). "
                f"Matched: {matches_found[:3]}{'...' if len(matches_found) > 3 else ''}"
            )
        
        return sanitized_prompt, is_valid, risk_score
