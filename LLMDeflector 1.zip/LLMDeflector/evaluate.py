"""
Core evaluation functions for scanning LLM inputs and outputs.
"""
from __future__ import annotations

import time
from typing import TYPE_CHECKING

from .utils import get_logger

if TYPE_CHECKING:
    from .input_scanners.base import InputScanner
    from .output_scanners.base import OutputScanner

LOGGER = get_logger(__name__)


def scan_input(
    scanners: list[InputScanner], prompt: str, fail_fast: bool = False
) -> tuple[str, dict[str, bool], dict[str, float]]:
    """
    Scans a given prompt using the provided rule-based scanners.

    Args:
        scanners: A list of input scanner objects.
        prompt: The input prompt string to be scanned.
        fail_fast: Stop scanning after the first scanner fails.

    Returns:
        A tuple containing:
            - The processed prompt string after applying all scanners.
            - A dictionary mapping scanner names to boolean values (True = valid).
            - A dictionary mapping scanner names to risk scores (0.0 = safe, 1.0 = high risk).
    """
    sanitized_prompt = prompt
    results_valid = {}
    results_score = {}

    if len(scanners) == 0 or prompt.strip() == "":
        return sanitized_prompt, results_valid, results_score

    start_time = time.time()
    for scanner in scanners:
        start_time_scanner = time.time()
        sanitized_prompt, is_valid, risk_score = scanner.scan(sanitized_prompt)
        elapsed_time_scanner = time.time() - start_time_scanner

        scanner_name = type(scanner).__name__
        LOGGER.debug(
            f"Scanner {scanner_name} completed: valid={is_valid}, "
            f"risk_score={risk_score:.2f}, time={elapsed_time_scanner:.4f}s"
        )

        results_valid[scanner_name] = is_valid
        results_score[scanner_name] = risk_score

        if fail_fast and not is_valid:
            LOGGER.info(f"Fail-fast triggered by {scanner_name}")
            break

    elapsed_time = time.time() - start_time
    LOGGER.info(f"Input scan completed in {elapsed_time:.4f}s, scores: {results_score}")

    return sanitized_prompt, results_valid, results_score


def scan_output(
    scanners: list[OutputScanner], prompt: str, output: str, fail_fast: bool = False
) -> tuple[str, dict[str, bool], dict[str, float]]:
    """
    Scans a given LLM output using the provided rule-based scanners.

    Args:
        scanners: A list of output scanner objects.
        prompt: The input prompt that produced the output.
        output: The output string to be scanned.
        fail_fast: Stop scanning after the first scanner fails.

    Returns:
        A tuple containing:
            - The processed output string after applying all scanners.
            - A dictionary mapping scanner names to boolean values (True = valid).
            - A dictionary mapping scanner names to risk scores (0.0 = safe, 1.0 = high risk).
    """
    sanitized_output = output
    results_valid = {}
    results_score = {}

    if len(scanners) == 0 or output is None or output.strip() == "":
        return sanitized_output, results_valid, results_score

    start_time = time.time()
    for scanner in scanners:
        start_time_scanner = time.time()
        sanitized_output, is_valid, risk_score = scanner.scan(prompt, sanitized_output)
        elapsed_time_scanner = time.time() - start_time_scanner

        scanner_name = type(scanner).__name__
        LOGGER.debug(
            f"Scanner {scanner_name} completed: valid={is_valid}, "
            f"risk_score={risk_score:.2f}, time={elapsed_time_scanner:.4f}s"
        )

        results_valid[scanner_name] = is_valid
        results_score[scanner_name] = risk_score

        if fail_fast and not is_valid:
            LOGGER.info(f"Fail-fast triggered by {scanner_name}")
            break

    elapsed_time = time.time() - start_time
    LOGGER.info(f"Output scan completed in {elapsed_time:.4f}s, scores: {results_score}")

    return sanitized_output, results_valid, results_score
