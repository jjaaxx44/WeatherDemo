"""Vault for storing anonymized data."""
from __future__ import annotations


class Vault:
    """
    Storage for anonymized data that can be used for deanonymization.
    
    Stores tuples of (placeholder, original_value) for later retrieval.
    """

    def __init__(self, tuples: list[tuple[str, str]] | None = None):
        """
        Initialize the vault.
        
        Args:
            tuples: Optional initial list of (placeholder, value) tuples.
        """
        if tuples is None:
            tuples = []
        self._tuples = tuples

    def append(self, new_tuple: tuple[str, str]):
        """Add a new tuple to the vault."""
        self._tuples.append(new_tuple)

    def extend(self, new_tuples: list[tuple[str, str]]):
        """Add multiple tuples to the vault."""
        self._tuples.extend(new_tuples)

    def remove(self, tuple_to_remove: tuple[str, str]):
        """Remove a tuple from the vault."""
        self._tuples.remove(tuple_to_remove)

    def get(self) -> list[tuple[str, str]]:
        """Get all tuples from the vault."""
        return self._tuples

    def placeholder_exists(self, placeholder: str) -> bool:
        """Check if a placeholder exists in the vault."""
        for entity_placeholder, _ in self._tuples:
            if placeholder == entity_placeholder:
                return True
        return False
    
    def get_value(self, placeholder: str) -> str | None:
        """Get the original value for a placeholder."""
        for entity_placeholder, value in self._tuples:
            if placeholder == entity_placeholder:
                return value
        return None
    
    def clear(self):
        """Clear all tuples from the vault."""
        self._tuples.clear()
