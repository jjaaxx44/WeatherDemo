"""Examples for LLMG usage."""
