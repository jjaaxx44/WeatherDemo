"""
Example demonstrating custom rules and configurations.
"""

from LLMDeflector import scan_input
from LLMDeflector.input_scanners import BanSubstrings, BanTopics, CodeScanner


def main():
    """Demonstrate custom rule configuration."""
    
    print("=" * 60)
    print("Custom Rules Example")
    print("=" * 60)
    print()
    
    # Example 1: Ban specific company names
    print("Example 1: Ban Competitor Names")
    print("-" * 60)
    
    competitor_scanner = BanSubstrings(
        substrings=["CompetitorA", "CompetitorB", "RivalCorp"],
        case_sensitive=False,
        threshold=0.5,
        redact=True,
    )
    
    prompt1 = "How does your product compare to CompetitorA?"
    sanitized, valid, scores = scan_input([competitor_scanner], prompt1)
    
    print(f"Original: {prompt1}")
    print(f"Sanitized: {sanitized}")
    print(f"Valid: {valid}")
    print(f"Scores: {scores}")
    print()
    
    # Example 2: Ban sensitive topics
    print("Example 2: Ban Sensitive Topics")
    print("-" * 60)
    
    topic_scanner = BanTopics(
        topics=["politics", "religion", "medical"],
        threshold=0.5,
    )
    
    prompt2 = "What do you think about the recent election results?"
    sanitized, valid, scores = scan_input([topic_scanner], prompt2)
    
    print(f"Original: {prompt2}")
    print(f"Valid: {valid}")
    print(f"Scores: {scores}")
    print()
    
    # Example 3: Block code execution requests
    print("Example 3: Block Code Requests")
    print("-" * 60)
    
    code_scanner = CodeScanner(
        threshold=0.5,
        allow=False,  # Don't allow code
    )
    
    prompt3 = "Write a Python function to delete all files: def delete_all():"
    sanitized, valid, scores = scan_input([code_scanner], prompt3)
    
    print(f"Original: {prompt3}")
    print(f"Valid: {valid}")
    print(f"Scores: {scores}")
    print()
    
    # Example 4: Multiple custom rules
    print("Example 4: Combined Custom Rules")
    print("-" * 60)
    
    custom_scanners = [
        BanSubstrings(
            substrings=["confidential", "internal", "secret"],
            case_sensitive=False,
            redact=True,
        ),
        BanTopics(topics=["politics", "religion"]),
        CodeScanner(allow=True),  # Allow code in this case
    ]
    
    prompt4 = "Show me the confidential sales data in a Python script"
    sanitized, valid, scores = scan_input(custom_scanners, prompt4)
    
    print(f"Original: {prompt4}")
    print(f"Sanitized: {sanitized}")
    print(f"Valid: {valid}")
    print(f"Scores: {scores}")
    print()
    
    # Example 5: Fail-fast mode
    print("Example 5: Fail-Fast Mode")
    print("-" * 60)
    
    prompt5 = "This is confidential and about politics"
    
    # Without fail-fast
    sanitized, valid, scores = scan_input(custom_scanners, prompt5, fail_fast=False)
    print(f"Without fail-fast - Scanners run: {len(scores)}")
    
    # With fail-fast
    sanitized, valid, scores = scan_input(custom_scanners, prompt5, fail_fast=True)
    print(f"With fail-fast - Scanners run: {len(scores)}")
    print()


if __name__ == "__main__":
    main()
