"""
Example demonstrating anonymization and deanonymization.
"""

from LLMDeflector import scan_input, scan_output
from LLMDeflector.input_scanners import Anonymize
from LLMDeflector.output_scanners import Deanonymize
from LLMDeflector.vault import Vault


def main():
    """Demonstrate anonymization workflow."""
    
    print("=" * 60)
    print("Anonymization and Deanonymization Example")
    print("=" * 60)
    print()
    
    # Initialize vault
    vault = Vault()
    
    # Set up scanners
    input_scanners = [Anonymize(vault=vault)]
    output_scanners = [Deanonymize(vault=vault)]
    
    # Original prompt with PII
    prompt = (
        "My name is John Doe. You can reach me at john.doe@example.com "
        "or call me at 555-123-4567. My credit card is 4532-1234-5678-9010."
    )
    
    print("Step 1: Original Prompt")
    print("-" * 60)
    print(prompt)
    print()
    
    # Anonymize the prompt
    sanitized_prompt, valid_results, risk_scores = scan_input(input_scanners, prompt)
    
    print("Step 2: Anonymized Prompt (sent to LLM)")
    print("-" * 60)
    print(sanitized_prompt)
    print()
    
    print("Step 3: Vault Contents")
    print("-" * 60)
    for placeholder, original in vault.get():
        print(f"  {placeholder} -> {original}")
    print()
    
    # Simulate LLM response that includes placeholders
    llm_response = (
        "Thank you for providing your information. "
        "I've noted your email as [EMAIL_1] and phone as [PHONE_1]. "
        "Your credit card [CREDIT_CARD_1] has been processed."
    )
    
    print("Step 4: LLM Response (with placeholders)")
    print("-" * 60)
    print(llm_response)
    print()
    
    # Deanonymize the response
    final_output, valid_results, risk_scores = scan_output(
        output_scanners, sanitized_prompt, llm_response
    )
    
    print("Step 5: Deanonymized Output (returned to user)")
    print("-" * 60)
    print(final_output)
    print()
    
    print("=" * 60)
    print("Complete! PII was protected during LLM processing.")
    print("=" * 60)


if __name__ == "__main__":
    main()
