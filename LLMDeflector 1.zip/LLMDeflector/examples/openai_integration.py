"""
Example integration with OpenAI API.

Note: This requires the openai package and an API key.
Install: pip install openai
Set environment variable: OPENAI_API_KEY=your_key_here
"""

import os

try:
    from openai import OpenAI
except ImportError:
    print("This example requires the openai package.")
    print("Install it with: pip install openai")
    exit(1)

from LLMDeflector import scan_input, scan_output
from LLMDeflector.input_scanners import Anonymize, PromptInjection, Secrets, Toxicity
from LLMDeflector.output_scanners import Deanonymize, NoRefusal, Relevance, SensitiveData
from LLMDeflector.vault import Vault


def main():
    """Demonstrate LLMDeflector with OpenAI API."""
    
    # Check for API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Error: OPENAI_API_KEY environment variable not set")
        print("Set it with: export OPENAI_API_KEY=your_key_here")
        return
    
    # Initialize OpenAI client
    client = OpenAI(api_key=api_key)
    
    # Initialize vault and scanners
    vault = Vault()
    
    input_scanners = [
        Anonymize(vault=vault),
        PromptInjection(threshold=0.5),
        Secrets(threshold=0.5, redact=True),
        Toxicity(threshold=0.5),
    ]
    
    output_scanners = [
        Deanonymize(vault=vault),
        NoRefusal(threshold=0.5),
        Relevance(threshold=0.3),
        SensitiveData(threshold=0.5, redact=True),
    ]
    
    # Example prompt with PII
    user_prompt = (
        "My name is John Doe and my email is john@example.com. "
        "Can you help me understand how LLMs work?"
    )
    
    print("=" * 60)
    print("LLMDeflector + OpenAI Integration Example")
    print("=" * 60)
    print()
    
    print("Step 1: Original User Prompt")
    print("-" * 60)
    print(user_prompt)
    print()
    
    # Scan input
    sanitized_prompt, input_valid, input_scores = scan_input(
        input_scanners, user_prompt
    )
    
    print("Step 2: Input Scan Results")
    print("-" * 60)
    print(f"Sanitized prompt: {sanitized_prompt}")
    print(f"Valid: {input_valid}")
    print(f"Risk scores: {input_scores}")
    print()
    
    # Check if input is safe
    if not all(input_valid.values()):
        print("⚠️  Input rejected due to security concerns!")
        print("Risky scanners:", [k for k, v in input_valid.items() if not v])
        return
    
    print("✓ Input passed security checks")
    print()
    
    # Call OpenAI API
    print("Step 3: Calling OpenAI API...")
    print("-" * 60)
    
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": sanitized_prompt},
            ],
            temperature=0.7,
            max_tokens=200,
        )
        
        llm_output = response.choices[0].message.content
        print(f"LLM Response: {llm_output}")
        print()
        
    except Exception as e:
        print(f"Error calling OpenAI API: {e}")
        return
    
    # Scan output
    print("Step 4: Output Scan Results")
    print("-" * 60)
    
    sanitized_output, output_valid, output_scores = scan_output(
        output_scanners, sanitized_prompt, llm_output
    )
    
    print(f"Sanitized output: {sanitized_output}")
    print(f"Valid: {output_valid}")
    print(f"Risk scores: {output_scores}")
    print()
    
    # Check if output is safe
    if not all(output_valid.values()):
        print("⚠️  Output rejected due to security concerns!")
        print("Risky scanners:", [k for k, v in output_valid.items() if not v])
        return
    
    print("✓ Output passed security checks")
    print()
    
    print("Step 5: Final Response to User")
    print("-" * 60)
    print(sanitized_output)
    print()
    
    print("=" * 60)
    print("✓ Complete! Both input and output were secured.")
    print("=" * 60)


if __name__ == "__main__":
    main()
